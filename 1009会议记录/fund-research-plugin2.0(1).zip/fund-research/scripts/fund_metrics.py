"""fund-research 1.2 deterministic research components; Python standard library only.

CLI:
  python fund_metrics.py tri --input nav.csv --output tri.csv
      nav.csv columns: date,unit_nav[,distribution][,split_ratio]
  python fund_metrics.py nav --input tri.csv --output metrics.json --confirmed-total-return
      [--benchmark bench.csv] [--calendar cal.csv] [--annual-rf 0.015] [--periods 252]
      cal.csv: column `date` or `trade_date` = trading calendar (e.g. akshare tool_trade_date_hist_sina);
      without --calendar, benchmark dates are used only with --benchmark-is-calendar (you confirm the
      benchmark is complete at the analysis frequency); otherwise per-period/annualized metrics are withheld.
      tri.csv / bench.csv columns: date,total_return_index  (bench may use date,close)
"""
import argparse
import csv
import json
import math
import statistics
from datetime import date

VERSION = '1.2.3'


def _finite(xs):
    return all(isinstance(x, (int, float)) and math.isfinite(x) for x in xs)


def total_return_index(unit_nav, distributions=None, split_ratios=None):
    """Dividend-reinvested index from unit NAV.

    distributions[t]: cash per pre-event unit going ex on day t (reinvested at close t).
    split_ratios[t]: units after / units before for a split effective on day t (1 = none).
    growth_t = (unit_nav_t * split_t + dist_t) / unit_nav_{t-1}
    """
    n = len(unit_nav)
    distributions = distributions or [0.0] * n
    split_ratios = split_ratios or [1.0] * n
    if n < 2 or len(distributions) != n or len(split_ratios) != n:
        raise ValueError('aligned NAV, distribution and split series required')
    if not _finite(unit_nav + distributions + split_ratios):
        raise ValueError('finite values required')
    if any(x <= 0 for x in unit_nav) or any(x < 0 for x in distributions) or any(x <= 0 for x in split_ratios):
        raise ValueError('positive NAV/split ratios and nonnegative distributions required')
    out = [1.0]
    for i in range(1, n):
        out.append(out[-1] * (unit_nav[i] * split_ratios[i] + distributions[i]) / unit_nav[i - 1])
    return out


def _check_series(dates, values, calendar=None, periods=252, calendar_confirmed=True):
    """Single validation point for every return series.

    calendar: trading dates (ISO strings) at the analysis frequency. Per-period statistics are
    valid only if ALL of the following hold; otherwise `reasons` explains why they are withheld:
      - a calendar is given and it covers the whole series range [start, end];
      - every series date is on the calendar (off-calendar dates must be removed/fixed first);
      - no calendar date inside the range is missing (else some returns span several periods);
      - calendar density matches `periods` (+-20%, checked when the range spans >= 90 days);
      - calendar_confirmed: a calendar derived from benchmark dates must be explicitly confirmed
        as complete and at the intended frequency; identical dates alone are not proof.
    """
    if len(dates) != len(values) or len(values) < 3:
        raise ValueError('at least three aligned observations required')
    parsed = [date.fromisoformat(d) for d in dates]
    if any(b <= a for a, b in zip(parsed, parsed[1:])):
        raise ValueError('dates must be unique and increasing')
    if not _finite(values) or any(x <= 0 for x in values):
        raise ValueError('positive finite total return index required')
    if periods <= 0:
        raise ValueError('periods must be positive')
    result = {'calendar_checked': False, 'missing': [], 'off_calendar': [], 'reasons': []}
    cal = sorted({date.fromisoformat(c) for c in (calendar or [])})
    if not cal:
        result['reasons'].append('no_calendar')
    else:
        result['calendar_checked'] = True
        if cal[0] > parsed[0] or cal[-1] < parsed[-1]:
            result['reasons'].append(f'calendar_not_covering_range({cal[0]}..{cal[-1]} vs {parsed[0]}..{parsed[-1]})')
        calset, have = set(cal), set(parsed)
        result['off_calendar'] = [str(d) for d in parsed if d not in calset]
        if result['off_calendar']:
            result['reasons'].append('off_calendar_dates')
        in_range = [c for c in cal if parsed[0] <= c <= parsed[-1]]
        result['missing'] = [str(c) for c in in_range if c not in have]
        if result['missing']:
            result['reasons'].append('missing_calendar_dates')
        span = (parsed[-1] - parsed[0]).days
        if span >= 90 and len(in_range) > 1:
            density = (len(in_range) - 1) / (span / 365.25)
            result['calendar_periods_per_year'] = round(density, 1)
            if not 0.8 * periods <= density <= 1.2 * periods:
                result['reasons'].append(f'frequency_mismatch(calendar~{density:.0f}/yr vs periods={periods})')
        if not calendar_confirmed:
            result['reasons'].append('benchmark_calendar_unconfirmed')
    result['per_period_valid'] = not result['reasons']
    return result


def drawdown_profile(dates, values):
    peak_i, best = 0, (0.0, 0, 0)
    for i, v in enumerate(values):
        if v > values[peak_i]:
            peak_i = i
        dd = 1 - v / values[peak_i]
        if dd > best[0]:
            best = (dd, peak_i, i)
    dd, p, t = best
    rec = next((i for i in range(t + 1, len(values)) if values[i] >= values[p]), None)
    return {'max_drawdown': dd,
            'peak_date': dates[p] if dd > 0 else None,
            'trough_date': dates[t] if dd > 0 else None,
            'recovery_date': dates[rec] if (dd > 0 and rec is not None) else None,
            'recovered': (rec is not None) if dd > 0 else True}


def performance(dates, values, annual_rf=0.015, periods=252, calendar=None, calendar_confirmed=True):
    check = _check_series(dates, values, calendar, periods, calendar_confirmed)
    if not math.isfinite(annual_rf) or annual_rf <= -1 or periods <= 0:
        raise ValueError('invalid annualization parameters')
    returns = [b / a - 1 for a, b in zip(values, values[1:])]
    rf = (1 + annual_rf) ** (1 / periods) - 1
    jumps = [{'date': dates[i + 1], 'return': r} for i, r in enumerate(returns) if abs(r) > .1]
    ok = check['per_period_valid']
    vol = statistics.stdev(returns)
    cumulative = values[-1] / values[0] - 1
    ann = (1 + cumulative) ** (periods / len(returns)) - 1 if ok else None
    downside = math.sqrt(statistics.fmean([min(r - rf, 0) ** 2 for r in returns]))
    dd = drawdown_profile(dates, values)
    mean_ex = statistics.fmean(returns) - rf
    return {
        'version': VERSION,
        'cumulative_return': cumulative,
        'annualized_return': ann,
        'annualized_volatility': vol * math.sqrt(periods) if ok else None,
        'sharpe': mean_ex / vol * math.sqrt(periods) if ok and vol else None,
        'sortino': mean_ex / downside * math.sqrt(periods) if ok and downside else None,
        'calmar': ann / dd['max_drawdown'] if ok and dd['max_drawdown'] else None,
        **dd,
        'period_rf': rf, 'annual_rf': annual_rf, 'periods_per_year': periods, 'return_count': len(returns),
        'calendar_checked': check['calendar_checked'], 'missing_dates': check['missing'],
        'off_calendar_dates': check['off_calendar'], 'withheld_reasons': check['reasons'],
        'jumps_to_review': jumps,
        'status_hint': 'formal_if_index_verified' if ok else 'insufficient',
        'note': ('Per-period and annualized metrics require a complete series against the trading calendar; '
                 'cumulative return and drawdown do not.'),
    }


def _ols(x, y):
    mx, my = statistics.fmean(x), statistics.fmean(y)
    sxx = sum((a - mx) ** 2 for a in x)
    if sxx == 0:
        return None, None
    beta = sum((a - mx) * (b - my) for a, b in zip(x, y)) / sxx
    return my - beta * mx, beta


def relative(fund_dates, fund_values, bench_dates, bench_values, annual_rf=0.015, periods=252,
             calendar=None, benchmark_is_calendar=False):
    """Benchmark-relative metrics on common dates only (no zero-filling of unmatched days).

    Without an explicit calendar, benchmark dates serve as the calendar only when
    benchmark_is_calendar=True (caller confirms completeness and frequency). After alignment the common series is checked
    again; if any calendar date inside the common range is missing, per-period statistics
    (TE, IR, beta, alpha, capture, win rate) are withheld because some returns span several periods.
    """
    explicit = calendar is not None
    cal = list(calendar) if explicit else list(bench_dates)
    confirmed = explicit or benchmark_is_calendar
    b_map = dict(zip(bench_dates, bench_values))
    common = [(d, v, b_map[d]) for d, v in zip(fund_dates, fund_values) if d in b_map]
    if len(common) < 3:
        raise ValueError('fewer than three common dates')
    d, p, b = zip(*common)
    # Check each input on the common range itself, so dates dropped by the intersection
    # (fund off-calendar days, gaps in a confirmed-but-incomplete benchmark) are not silently ignored,
    # while a longer fund history outside the benchmark range does not block the comparison.
    lo, hi = d[0], d[-1]
    def window(ds, vs):
        pairs = [(x, y) for x, y in zip(ds, vs) if lo <= x <= hi]
        return [x for x, _ in pairs], [y for _, y in pairs]
    fund_check = _check_series(*window(fund_dates, fund_values), cal, periods, confirmed)
    bench_check = _check_series(*window(bench_dates, bench_values), cal, periods, confirmed)
    aligned = _check_series(list(d), list(p), cal, periods, confirmed)
    for label, chk in (('fund', fund_check), ('bench', bench_check)):
        aligned['reasons'] += [f'{label}:{r}' for r in chk['reasons'] if r not in aligned['reasons']]
    ok = not aligned['reasons']
    Rp, Rb = p[-1] / p[0] - 1, b[-1] / b[0] - 1
    out = {
        'version': VERSION,
        'common_dates': len(d), 'start': d[0], 'end': d[-1],
        'fund_missing_dates': fund_check['missing'], 'bench_missing_dates': bench_check['missing'],
        'fund_off_calendar_dates': fund_check['off_calendar'],
        'aligned_missing_dates': aligned['missing'], 'withheld_reasons': aligned['reasons'],
        'fund_cumulative': Rp, 'bench_cumulative': Rb,
        'arithmetic_excess': Rp - Rb, 'relative_wealth_excess': (1 + Rp) / (1 + Rb) - 1,
        'tracking_error': None, 'information_ratio': None, 'beta': None,
        'alpha_annualized_arith': None, 'up_capture': None, 'down_capture': None, 'period_win_rate': None,
        'status_hint': 'formal_if_index_verified' if ok else 'insufficient',
        'note': 'OLS point estimates without standard errors; report significance from a regression tool before inferring skill.',
    }
    if not ok:
        return out
    rp = [y / x - 1 for x, y in zip(p, p[1:])]
    rb = [y / x - 1 for x, y in zip(b, b[1:])]
    rf = (1 + annual_rf) ** (1 / periods) - 1
    active = [x - y for x, y in zip(rp, rb)]
    te = statistics.stdev(active)
    alpha_p, beta = _ols([x - rf for x in rb], [y - rf for y in rp])

    def capture(sel):
        # Ratio of mean period returns on benchmark up (down) periods. Compounding returns across
        # non-contiguous periods explodes over long samples (down capture collapses to ~1.0).
        idx = [i for i, x in enumerate(rb) if sel(x)]
        if not idx:
            return None
        mb = statistics.fmean(rb[i] for i in idx)
        return None if abs(mb) < 1e-12 else statistics.fmean(rp[i] for i in idx) / mb

    out.update({
        'tracking_error': te * math.sqrt(periods),
        'information_ratio': statistics.fmean(active) / te * math.sqrt(periods) if te else None,
        'beta': beta,
        'alpha_annualized_arith': None if alpha_p is None else alpha_p * periods,
        'up_capture': capture(lambda x: x > 0), 'down_capture': capture(lambda x: x < 0),
        'period_win_rate': sum(1 for x in active if x > 0) / len(active),
    })
    return out


def structure_change_rate(prev, curr):
    """sum|Δw|/2 over the union of keys (dict security/industry -> weight). Not trading turnover."""
    keys = set(prev) | set(curr)
    if not keys or not _finite(list(prev.values()) + list(curr.values())):
        raise ValueError('finite nonempty weights required')
    return sum(abs(curr.get(k, 0.0) - prev.get(k, 0.0)) for k in keys) / 2


def drift_weights(weights, returns, tol=1e-6):
    """Buy-and-hold drift of a COMPLETE portfolio (no trading).

    weights must cover all assets and sum to 1 (fraction of NAV). For disclosed top-10 holdings,
    add explicit entries for the undisclosed equity part and for cash/bonds (each with its own
    proxy return) before calling; partial weights are rejected rather than silently rescaled.
    """
    if not weights or set(weights) != set(returns):
        raise ValueError('weights and returns must have identical nonempty keys')
    w, r = list(weights.values()), list(returns.values())
    if not _finite(w + r):
        raise ValueError('finite weights and returns required')
    if any(x < 0 for x in w):
        raise ValueError('nonnegative weights required')
    if any(x <= -1 for x in r):
        raise ValueError('returns must be greater than -100%')
    if abs(sum(w) - 1) > tol:
        raise ValueError(f'weights sum to {sum(w):.6f}, not 1: add undisclosed-equity and cash/bond entries explicitly')
    grown = {k: weights[k] * (1 + returns[k]) for k in weights}
    total = sum(grown.values())
    return {k: v / total for k, v in grown.items()}


def concentration(weights, complete=True):
    """HHI and effective count; on partial (top10) data label as disclosed-sample concentration."""
    w = list(weights)
    if not w or not _finite(w) or any(x < 0 for x in w) or sum(w) <= 0:
        raise ValueError('nonempty, finite, nonnegative weights with positive sum required')
    s = sum(w)
    norm = [x / s for x in w if x > 0]
    hhi = sum(x * x for x in norm)
    return {'hhi': hhi, 'effective_n': 1 / hhi, 'top1': max(norm),
            'top3': sum(sorted(norm, reverse=True)[:3]), 'raw_weight_sum': s,
            'scope': 'full_portfolio' if complete else 'disclosed_sample'}


def bf(stock_weights, benchmark_weights, stock_returns, benchmark_returns):
    """Two-effect BF for normalized stock portfolios, interaction included in selection."""
    arrays = [stock_weights, benchmark_weights, stock_returns, benchmark_returns]
    if len({len(x) for x in arrays}) != 1 or not stock_weights:
        raise ValueError('aligned nonempty industry vectors required')
    if not _finite([v for x in arrays for v in x]):
        raise ValueError('finite values required')
    if any(v < 0 for x in arrays[:2] for v in x) or any(not math.isclose(sum(x), 1, abs_tol=1e-9) for x in arrays[:2]):
        raise ValueError('nonnegative normalized weights required')
    rb = sum(w * r for w, r in zip(benchmark_weights, benchmark_returns))
    rp = sum(w * r for w, r in zip(stock_weights, stock_returns))
    ar = [(p - b) * (r - rb) for p, b, r in zip(stock_weights, benchmark_weights, benchmark_returns)]
    sr = [p * (r - b) for p, r, b in zip(stock_weights, stock_returns, benchmark_returns)]
    return {'allocation': ar, 'selection_including_interaction': sr, 'portfolio_return': rp,
            'benchmark_return': rb, 'closure_error': rp - rb - sum(ar) - sum(sr)}


def grap(portfolio_returns, benchmark_returns, effects):
    """Link effect vectors that already sum to each period's arithmetic excess.
    Linked effects sum to the cumulative ARITHMETIC excess (R_p - R_b), not relative wealth."""
    if not portfolio_returns or len(portfolio_returns) != len(benchmark_returns) or len(effects) != len(portfolio_returns):
        raise ValueError('aligned nonempty periods required')
    widths = {len(e) for e in effects}
    if len(widths) != 1 or 0 in widths:
        raise ValueError('consistent nonempty effect vectors required')
    if not _finite(portfolio_returns + benchmark_returns) or any(r <= -1 for r in portfolio_returns + benchmark_returns):
        raise ValueError('returns must be finite and greater than -1')
    for p, b, e in zip(portfolio_returns, benchmark_returns, effects):
        if not _finite(e) or not math.isclose(sum(e), p - b, abs_tol=1e-9):
            raise ValueError('single-period effects must close before linking')
    linked = [0.0] * len(effects[0])
    for t, e in enumerate(effects):
        g = math.prod(1 + r for r in portfolio_returns[:t]) * math.prod(1 + r for r in benchmark_returns[t + 1:])
        for k, v in enumerate(e):
            linked[k] += g * v
    excess = math.prod(1 + r for r in portfolio_returns) - math.prod(1 + r for r in benchmark_returns)
    return {'linked_effects': linked, 'arithmetic_cumulative_excess': excess, 'closure_error': excess - sum(linked)}


def _read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def _series(rows, col_candidates):
    col = next((c for c in col_candidates if rows and c in rows[0]), None)
    if col is None:
        raise SystemExit(f'missing column; expected one of {col_candidates}')
    return [r['date'] for r in rows], [float(r[col]) for r in rows]


def main():
    ap = argparse.ArgumentParser(description=f'fund-research metrics {VERSION}')
    ap.add_argument('command', choices=['nav', 'tri'])
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--benchmark')
    ap.add_argument('--confirmed-total-return', action='store_true')
    ap.add_argument('--annual-rf', type=float, default=.015)
    ap.add_argument('--calendar')
    ap.add_argument('--benchmark-is-calendar', action='store_true')
    ap.add_argument('--periods', type=int, default=252)
    a = ap.parse_args()
    rows = _read_csv(a.input)
    if a.command == 'tri':
        nav = [float(r['unit_nav']) for r in rows]
        dist = [float(r.get('distribution') or 0) for r in rows]
        split = [float(r.get('split_ratio') or 1) for r in rows]
        idx = total_return_index(nav, dist, split)
        with open(a.output, 'w', encoding='utf-8', newline='') as f:
            w = csv.writer(f)
            w.writerow(['date', 'total_return_index'])
            w.writerows([r['date'], f'{v:.10f}'] for r, v in zip(rows, idx))
        return
    if not a.confirmed_total_return:
        ap.error('confirm input is a dividend-reinvested total return index (use `tri` to build one); cumulative NAV is not sufficient')
    d, v = _series(rows, ['total_return_index'])
    bd = bv = None
    if a.benchmark:
        bd, bv = _series(_read_csv(a.benchmark), ['total_return_index', 'close'])
    explicit = [r.get('date') or r['trade_date'] for r in _read_csv(a.calendar)] if a.calendar else None
    cal = explicit if explicit is not None else bd
    confirmed = explicit is not None or a.benchmark_is_calendar
    out = {'calendar_source': 'file' if explicit is not None else ('benchmark' if bd else None),
           'calendar_confirmed': bool(cal) and confirmed,
           'performance': performance(d, v, a.annual_rf, a.periods, cal, confirmed)}
    if bd:
        out['relative'] = relative(d, v, bd, bv, a.annual_rf, a.periods, explicit, a.benchmark_is_calendar)
    with open(a.output, 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2, allow_nan=False)


if __name__ == '__main__':
    main()
