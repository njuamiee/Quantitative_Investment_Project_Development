"""Fill references/templates/dashboard.html with computed numbers (standard library only).

Numbers come only from fund_metrics.py output and the series files; the caller supplies text
(module conclusions, overall judgement, notes) in meta.json. No values are typed by hand.

python render_dashboard.py --metrics metrics.json --tri tri.csv [--benchmark bench.csv] \
    --meta meta.json --output 110011_业绩评价_20260930.html

meta.json:
{
  "title": "易方达优质精选混合", "short_name": "基金", "code": "110011", "report": "业绩评价",
  "as_of": "2026-09-30", "benchmark_name": "中证800（价格指数代理）", "benchmark_short": "中证800",
  "modules": [{"name": "业绩", "status": "formal|proxy|insufficient", "conclusion": "...", "limits": "..."}],
  "conclusions": ["..."], "notes": ["..."]
}
"""
import argparse
import csv
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, '..', 'references', 'templates', 'dashboard.html')


def _series(path, cols):
    with open(path, encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    col = next((c for c in cols if rows and c in rows[0]), None)
    if col is None:
        raise SystemExit(f'{path}: expected one of {cols}')
    return [r['date'] for r in rows], [float(r[col]) for r in rows]


def build_kpis(metrics):
    p, r = metrics.get('performance', {}), metrics.get('relative') or {}
    st = p.get('status_hint')
    status = 'formal' if st == 'formal_if_index_verified' else 'insufficient'
    why = '；'.join(p.get('withheld_reasons') or [])
    k = [
        {'label': '累计收益', 'value': p.get('cumulative_return'), 'format': 'pct',
         'foot': f"基准 {r['bench_cumulative']*100:.1f}%" if r.get('bench_cumulative') is not None else ''},
        {'label': '年化收益', 'value': p.get('annualized_return'), 'format': 'pct', 'status': status,
         'foot': why and '未计算：' + why},
        {'label': '最大回撤', 'value': -p['max_drawdown'] if p.get('max_drawdown') is not None else None, 'format': 'pct',
         'foot': (f"{p.get('peak_date')} → {p.get('trough_date')}" + ('' if p.get('recovered') else '，未修复'))
                 if p.get('peak_date') else ''},
        {'label': '年化波动', 'value': p.get('annualized_volatility'), 'format': 'pct', 'status': status},
        {'label': '夏普比率', 'value': p.get('sharpe'), 'format': 'num', 'status': status,
         'foot': f"rf {p.get('annual_rf', 0)*100:.1f}%"},
    ]
    if r:
        rstatus = 'formal' if r.get('status_hint') == 'formal_if_index_verified' else 'insufficient'
        k += [
            {'label': '累计超额（算术）', 'value': r.get('arithmetic_excess'), 'format': 'pct_signed'},
            {'label': '信息比率', 'value': r.get('information_ratio'), 'format': 'num', 'status': rstatus,
             'foot': f"跟踪误差 {r['tracking_error']*100:.1f}%" if r.get('tracking_error') is not None else ''},
        ]
    return k


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--metrics', required=True)
    ap.add_argument('--tri', required=True)
    ap.add_argument('--benchmark')
    ap.add_argument('--meta', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--template', default=TEMPLATE)
    a = ap.parse_args()
    with open(a.metrics, encoding='utf-8') as f:
        metrics = json.load(f)
    with open(a.meta, encoding='utf-8') as f:
        meta = json.load(f)
    d, v = _series(a.tri, ['total_return_index'])
    series = {'dates': d, 'fund': v, 'bench': None}
    if a.benchmark:
        bd, bv = _series(a.benchmark, ['total_return_index', 'close'])
        bmap = dict(zip(bd, bv))
        # Fund keeps its complete series (drawdown and yearly returns always use it); the benchmark is
        # mapped onto fund dates with null where it has no observation. Never drop fund dates.
        series = {'dates': d, 'fund': v, 'bench': [bmap.get(x) for x in d]}
        missing = sum(1 for x in series['bench'] if x is None)
        if missing:
            meta.setdefault('notes', []).append(f'基准在基金净值日中缺 {missing} 日，图中留空，未插值。')
    notes = list(meta.get('notes', []))
    rel = metrics.get('relative') or {}
    for label, part in (('业绩', metrics.get('performance', {})), ('相对基准', rel)):
        if part.get('withheld_reasons'):
            notes.append(f"{label}逐期指标未计算：{'；'.join(part['withheld_reasons'])}")
    if metrics.get('calendar_source'):
        notes.append(f"交易日历来源：{metrics['calendar_source']}（已确认：{'是' if metrics.get('calendar_confirmed') else '否'}）")
    data = {
        'meta': {k: meta.get(k) for k in ('title', 'short_name', 'code', 'report', 'as_of', 'benchmark_name', 'benchmark_short')},
        'kpis': build_kpis(metrics), 'series': series,
        'modules': meta.get('modules', []), 'conclusions': meta.get('conclusions', []), 'notes': notes,
    }
    payload = json.dumps(data, ensure_ascii=False, allow_nan=False).replace('</', '<\\/')
    with open(a.template, encoding='utf-8') as f:
        html = f.read()
    if '__DATA__' not in html:
        raise SystemExit('template placeholder __DATA__ not found')
    with open(a.output, 'w', encoding='utf-8') as f:
        f.write(html.replace('__DATA__', payload, 1))


if __name__ == '__main__':
    main()
