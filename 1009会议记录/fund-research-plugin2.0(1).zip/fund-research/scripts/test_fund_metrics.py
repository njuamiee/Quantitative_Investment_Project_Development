import csv
import json
import math
import os
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fund_metrics import (total_return_index, performance, relative, structure_change_rate,
                          drift_weights, concentration, bf, grap)


class ReturnIndex(unittest.TestCase):
    def test_distribution_is_not_cumulative_nav_ratio(self):
        # Ex-distribution then appreciation: reinvestment earns 10%; cumulative-NAV ratio gives 9%.
        idx = total_return_index([1, .9, .99], [0, .1, 0])
        self.assertAlmostEqual(idx[-1] - 1, .1)
        self.assertNotAlmostEqual(idx[-1] - 1, (.99 + .1) / 1 - 1)

    def test_split_is_neutral(self):
        # 1:2 split halves unit NAV without changing wealth.
        idx = total_return_index([2.0, 1.0, 1.1], split_ratios=[1, 2, 1])
        self.assertAlmostEqual(idx[1], 1.0)
        self.assertAlmostEqual(idx[2], 1.1)


CAL = ['2025-09-26', '2025-09-29', '2025-09-30', '2025-10-09', '2025-10-10', '2025-10-13', '2025-10-14']


class Performance(unittest.TestCase):
    def test_risk_free_and_drawdown(self):
        d = ['2026-01-05', '2026-01-06', '2026-01-07']
        out = performance(d, [1, 1.1, .99], calendar=d)
        self.assertAlmostEqual(out['max_drawdown'], .1)
        self.assertAlmostEqual((1 + out['period_rf']) ** 252, 1.015)
        self.assertEqual(out['peak_date'], '2026-01-06')
        self.assertFalse(out['recovered'])

    def test_holiday_is_not_a_missing_day(self):
        # National Day closure is absent from the calendar, so it is not a gap.
        out = performance(CAL[1:5], [1, 1.01, 1.02, 1.03], calendar=CAL)
        self.assertEqual(out['missing_dates'], [])
        self.assertIsNotNone(out['sharpe'])

    def test_missing_trading_day_blocks_per_period_metrics(self):
        out = performance(['2025-09-29', '2025-09-30', '2025-10-13', '2025-10-14'], [1, 1.01, 1.03, 1.04], calendar=CAL)
        self.assertEqual(out['missing_dates'], ['2025-10-09', '2025-10-10'])
        self.assertIsNone(out['annualized_volatility'])
        self.assertIsNone(out['sharpe'])
        self.assertAlmostEqual(out['cumulative_return'], .04)
        self.assertEqual(out['status_hint'], 'insufficient')

    def test_no_calendar_withholds_instead_of_guessing(self):
        out = performance(CAL[:4], [1, 1.01, 1.02, 1.03])
        self.assertFalse(out['calendar_checked'])
        self.assertIsNone(out['annualized_return'])
        self.assertIsNotNone(out['max_drawdown'])

    def test_off_calendar_dates_reported(self):
        out = performance(['2025-09-29', '2025-09-30', '2025-10-01', '2025-10-09'], [1, 1, 1, 1], calendar=CAL)
        self.assertEqual(out['off_calendar_dates'], ['2025-10-01'])

    def test_invalid_inputs(self):
        for ds, vs in [(['2026-01-01'] * 3, [1, 1, 1]), (['2026-01-01', '2026-01-02', '2026-01-03'], [1, 0, 1])]:
            with self.assertRaises(ValueError):
                performance(ds, vs)


class Relative(unittest.TestCase):
    def test_self_benchmark(self):
        v = [1, 1.02, 0.99, 1.01, 1.0, 1.03, 1.02]
        out = relative(CAL, v, CAL, v, benchmark_is_calendar=True)
        self.assertAlmostEqual(out['beta'], 1)
        self.assertAlmostEqual(out['arithmetic_excess'], 0)
        self.assertIsNone(out['information_ratio'])
        self.assertAlmostEqual(out['up_capture'], 1)

    def test_fund_missing_days_withhold_te_ir_alpha(self):
        # Fund lacks two trading days: after alignment one return would span three days.
        fd = ['2025-09-26', '2025-09-29', '2025-09-30', '2025-10-13', '2025-10-14']
        out = relative(fd, [1, 1.01, 1.0, 1.05, 1.06], CAL, [1, 1.0, 1.01, 1.02, 1.0, 1.01, 1.02],
                       benchmark_is_calendar=True)
        self.assertEqual(out['aligned_missing_dates'], ['2025-10-09', '2025-10-10'])
        for k in ['tracking_error', 'information_ratio', 'beta', 'alpha_annualized_arith', 'up_capture']:
            self.assertIsNone(out[k])
        self.assertAlmostEqual(out['fund_cumulative'], .06)
        self.assertEqual(out['status_hint'], 'insufficient')

    def test_benchmark_gap_detected_with_explicit_calendar(self):
        bd = ['2025-09-26', '2025-09-29', '2025-09-30', '2025-10-13', '2025-10-14']
        out = relative(CAL, [1, 1, 1.01, 1.02, 1.03, 1.02, 1.04], bd, [1, 1.01, 1.0, 1.02, 1.03], calendar=CAL)
        self.assertEqual(out['bench_missing_dates'], ['2025-10-09', '2025-10-10'])
        self.assertIsNone(out['information_ratio'])


class CalendarValidity(unittest.TestCase):
    D = CAL[1:5]
    V = [1, 1.01, 1.02, 1.03]

    def test_empty_calendar_withholds(self):
        out = performance(self.D, self.V, calendar=[])
        self.assertIsNone(out['annualized_return'])
        self.assertIn('no_calendar', out['withheld_reasons'])

    def test_calendar_not_covering_range_withholds(self):
        out = performance(self.D, self.V, calendar=['2024-01-02', '2024-01-03'])
        self.assertIsNone(out['sharpe'])
        self.assertTrue(any(r.startswith('calendar_not_covering_range') for r in out['withheld_reasons']))
        self.assertEqual(out['status_hint'], 'insufficient')

    def test_off_calendar_date_withholds_until_handled(self):
        d = ['2025-09-29', '2025-09-30', '2025-10-01', '2025-10-09']
        out = performance(d, self.V, calendar=CAL)
        self.assertIsNone(out['annualized_volatility'])
        self.assertIn('off_calendar_dates', out['withheld_reasons'])

    def test_benchmark_calendar_needs_confirmation(self):
        b = [1, 1.0, 1.01, 1.02, 1.0, 1.01, 1.02]
        out = relative(CAL, b, CAL, b)
        self.assertIsNone(out['information_ratio'])
        self.assertIn('benchmark_calendar_unconfirmed', out['withheld_reasons'])

    def test_both_weekly_caught_by_frequency_check(self):
        from datetime import date, timedelta
        weeks = [str(date(2025, 1, 3) + timedelta(weeks=i)) for i in range(30)]
        f = [1 + .01 * i for i in range(30)]
        b = [1 + .008 * i + (.002 if i % 2 else 0) for i in range(30)]
        out = relative(weeks, f, weeks, b, benchmark_is_calendar=True)  # periods=252 default
        self.assertIsNone(out['tracking_error'])
        self.assertTrue(any(r.startswith('frequency_mismatch') for r in out['withheld_reasons']))
        ok = relative(weeks, f, weeks, b, periods=52, benchmark_is_calendar=True)
        self.assertIsNotNone(ok['tracking_error'])

    def test_explicit_calendar_catches_shared_gap(self):
        # Fund and benchmark both miss 10-09/10-10: identical dates must not pass.
        d = ['2025-09-26', '2025-09-29', '2025-09-30', '2025-10-13', '2025-10-14']
        out = relative(d, [1, 1.01, 1.0, 1.05, 1.06], d, [1, 1.0, 1.01, 1.02, 1.03], calendar=CAL)
        self.assertEqual(out['aligned_missing_dates'], ['2025-10-09', '2025-10-10'])
        self.assertIsNone(out['information_ratio'])


class RelativeWindow(unittest.TestCase):
    def test_confirmed_benchmark_with_gap_does_not_drop_fund_dates(self):
        # Defect A (1.2.2): user confirms an incomplete benchmark as calendar; the fund's extra date
        # was silently dropped by the intersection and TE/IR were still reported.
        bd = ['2025-09-26', '2025-09-29', '2025-10-09', '2025-10-10', '2025-10-13']
        b = [1, 1.0, 1.01, 1.02, 1.03]
        out = relative(CAL[:6], [1, 1.01, 1.0, 1.02, 1.03, 1.04], bd, b, benchmark_is_calendar=True)
        self.assertEqual(out['fund_off_calendar_dates'], ['2025-09-30'])
        self.assertIsNone(out['information_ratio'])
        self.assertIn('fund:off_calendar_dates', out['withheld_reasons'])

    def test_longer_fund_history_does_not_block(self):
        b = [1, 1.0, 1.01, 1.02, 1.0, 1.01]
        f = [.9, .95] + [1, 1.01, 1.0, 1.02, 1.0, 1.03]
        fd = ['2025-09-24', '2025-09-25'] + CAL[:6]
        out = relative(fd, f, CAL[:6], b, benchmark_is_calendar=True)
        self.assertEqual(out['withheld_reasons'], [])
        self.assertIsNotNone(out['information_ratio'])


class CaptureRatio(unittest.TestCase):
    def test_long_sample_capture_is_stable(self):
        # Defect B (1.2.2): compounding non-contiguous up/down days over ~600 days drove
        # down_capture to ~1.0 and up_capture to nonsense. A fund with exactly half the
        # benchmark's daily moves must show ~0.5 on both sides.
        import random
        from datetime import date, timedelta
        rng = random.Random(7)
        days, d = [], date(2022, 1, 3)
        while len(days) < 650:
            if d.weekday() < 5:
                days.append(str(d))
            d += timedelta(days=1)
        rb = [rng.gauss(0.0004, 0.015) for _ in days[1:]]
        b, f = [1.0], [1.0]
        for r in rb:
            b.append(b[-1] * (1 + r)); f.append(f[-1] * (1 + .5 * r))
        out = relative(days, f, days, b, periods=260, benchmark_is_calendar=True)
        self.assertAlmostEqual(out['up_capture'], .5, places=9)
        self.assertAlmostEqual(out['down_capture'], .5, places=9)
        self.assertAlmostEqual(out['beta'], .5, places=9)


class Holdings(unittest.TestCase):
    def test_no_trade_still_changes_weights(self):
        # Fixed share counts; first stock doubles. Structure change > 0 with zero trading,
        # so snapshot weight change is neither turnover nor a lower bound of it.
        before = {'A': .5, 'B': .5}
        after = drift_weights(before, {'A': 1.0, 'B': 0.0})
        self.assertAlmostEqual(after['A'], 2 / 3)
        self.assertGreater(structure_change_rate(before, after), 0)

    def test_top10_must_be_completed_explicitly(self):
        top10 = {'S1': .08, 'S2': .07}
        with self.assertRaises(ValueError):
            drift_weights(top10, {'S1': .1, 'S2': 0})
        full = dict(top10, undisclosed_equity=.75, cash=.10)
        out = drift_weights(full, {'S1': .1, 'S2': 0, 'undisclosed_equity': .02, 'cash': 0})
        # S1 stays a fraction of NAV (~8.6%), not inflated to its share of disclosed stocks (~55%).
        self.assertAlmostEqual(out['S1'], .088 / 1.023, places=9)

    def test_drift_rejects_bad_inputs(self):
        for w, r in [({'A': 1.0}, {'A': float('nan')}), ({'A': 1.2, 'B': -.2}, {'A': 0, 'B': 0}),
                     ({'A': 1.0}, {'A': -1.0}), ({'A': 1.0}, {'B': 0})]:
            with self.assertRaises(ValueError):
                drift_weights(w, r)

    def test_concentration(self):
        out = concentration([.25] * 4)
        self.assertAlmostEqual(out['hhi'], .25)
        self.assertAlmostEqual(out['effective_n'], 4)
        self.assertEqual(concentration([.1, .05, 0], complete=False)['scope'], 'disclosed_sample')
        for bad in [[], [float('nan'), .5], [.5, -.1], [0, 0]]:
            with self.assertRaises(ValueError):
                concentration(bad)


class Attribution(unittest.TestCase):
    def test_stock_cash_bridge(self):
        out = bf([.6, .4], [.5, .5], [.1, -.02], [.08, .01])
        self.assertAlmostEqual(out['closure_error'], 0)
        qp, qb, cash = .7, .8, .005
        actual = qp * out['portfolio_return'] + (1 - qp) * cash
        bench = qb * out['benchmark_return'] + (1 - qb) * cash
        effects = qp * (sum(out['allocation']) + sum(out['selection_including_interaction'])) \
            + (qp - qb) * (out['benchmark_return'] - cash)
        self.assertAlmostEqual(actual - bench, effects)

    def test_grap_closure(self):
        out = grap([.1, -.04, .06], [.07, -.02, .03], [[.01, .02], [-.01, -.01], [.02, .01]])
        self.assertAlmostEqual(out['closure_error'], 0)
        with self.assertRaises(ValueError):
            grap([.1], [.05], [[.01]])


class CLI(unittest.TestCase):
    def test_tri_then_nav_with_benchmark(self):
        here = os.path.dirname(os.path.abspath(__file__))
        with tempfile.TemporaryDirectory() as t:
            nav, tri, bench, res = (os.path.join(t, n) for n in ['nav.csv', 'tri.csv', 'b.csv', 'r.json'])
            dates = ['2025-09-29', '2025-09-30', '2025-10-09', '2025-10-10', '2025-10-13']  # benchmark doubles as calendar
            with open(nav, 'w', newline='') as f:
                w = csv.writer(f); w.writerow(['date', 'unit_nav', 'distribution'])
                w.writerows(zip(dates, [1, 1.01, .92, .93, .95], [0, 0, .1, 0, 0]))
            with open(bench, 'w', newline='') as f:
                w = csv.writer(f); w.writerow(['date', 'close'])
                w.writerows(zip(dates, [100, 100.5, 101, 100.8, 101.5]))
            py = sys.executable
            subprocess.run([py, os.path.join(here, 'fund_metrics.py'), 'tri', '--input', nav, '--output', tri], check=True)
            run = lambda *extra: subprocess.run([py, os.path.join(here, 'fund_metrics.py'), 'nav', '--input', tri,
                                                 '--output', res, '--confirmed-total-return', '--benchmark', bench, *extra],
                                                check=True)
            run()
            with open(res) as fh:
                out = json.load(fh)
            self.assertFalse(out['calendar_confirmed'])
            self.assertIsNone(out['relative']['information_ratio'])
            self.assertIsNone(out['performance']['annualized_return'])
            run('--benchmark-is-calendar')
            with open(res) as fh:
                out = json.load(fh)
            self.assertIsNotNone(out['relative']['information_ratio'])
            self.assertIsNotNone(out['performance']['annualized_return'])
            r = subprocess.run([py, os.path.join(here, 'fund_metrics.py'), 'nav', '--input', tri, '--output', res],
                               capture_output=True)
            self.assertNotEqual(r.returncode, 0)


class Dashboard(unittest.TestCase):
    def test_render_fills_numbers_and_escapes(self):
        here = os.path.dirname(os.path.abspath(__file__))
        with tempfile.TemporaryDirectory() as t:
            j = lambda n: os.path.join(t, n)
            with open(j('tri.csv'), 'w', newline='') as f:
                w = csv.writer(f); w.writerow(['date', 'total_return_index'])
                w.writerows(zip(CAL, [1, 1.01, 1.0, 1.02, 1.03, 1.01, 1.04]))
            metrics = {'performance': performance(CAL, [1, 1.01, 1.0, 1.02, 1.03, 1.01, 1.04], calendar=CAL)}
            with open(j('m.json'), 'w') as f: json.dump(metrics, f)
            with open(j('meta.json'), 'w', encoding='utf-8') as f:
                json.dump({'title': 'T', 'code': '000001', 'notes': ['x</script><b>']}, f)
            subprocess.run([sys.executable, os.path.join(here, 'render_dashboard.py'), '--metrics', j('m.json'),
                            '--tri', j('tri.csv'), '--meta', j('meta.json'), '--output', j('o.html')], check=True)
            with open(j('o.html'), encoding='utf-8') as fh:
                html = fh.read()
            self.assertNotIn('__DATA__', html)
            self.assertNotIn('x</script>', html)
            self.assertIn('"label": "最大回撤"', html)

    def test_benchmark_gap_keeps_full_fund_series(self):
        # 1.2.3 bug: a benchmark gap on the fund's crash day removed that day from the page,
        # so the drawdown chart showed 0% while the KPI card showed -50%.
        here = os.path.dirname(os.path.abspath(__file__))
        fv = [1, 1, 0.5, 0.8, 1, 1.05, 1.1]
        with tempfile.TemporaryDirectory() as t:
            j = lambda n: os.path.join(t, n)
            with open(j('tri.csv'), 'w', newline='') as f:
                w = csv.writer(f); w.writerow(['date', 'total_return_index']); w.writerows(zip(CAL, fv))
            with open(j('b.csv'), 'w', newline='') as f:
                w = csv.writer(f); w.writerow(['date', 'close'])
                w.writerows((d, 100 + i) for i, d in enumerate(CAL) if i != 2)
            with open(j('m.json'), 'w') as f:
                json.dump({'performance': performance(CAL, fv, calendar=CAL)}, f)
            with open(j('meta.json'), 'w') as f:
                json.dump({'title': 'T'}, f)
            subprocess.run([sys.executable, os.path.join(here, 'render_dashboard.py'), '--metrics', j('m.json'),
                            '--tri', j('tri.csv'), '--benchmark', j('b.csv'), '--meta', j('meta.json'),
                            '--output', j('o.html')], check=True)
            with open(j('o.html'), encoding='utf-8') as fh:
                html = fh.read()
            data = json.loads(html.split('<script id="DATA" type="application/json">')[1].split('</script>')[0])
            self.assertEqual(data['series']['fund'], fv)
            self.assertEqual(data['series']['dates'], CAL)
            self.assertIsNone(data['series']['bench'][2])
            self.assertAlmostEqual(min(v / max(fv[:i + 1]) - 1 for i, v in enumerate(data['series']['fund'])), -0.5)


if __name__ == '__main__':
    unittest.main()
