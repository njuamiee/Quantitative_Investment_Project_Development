# 结构化结果契约

每个模块返回 JSON，数值不可计算用 null；JSON 不允许 NaN/Infinity。
```
{
  "schema_version": "1.2",
  "module": "performance",
  "mode": "compute_only",
  "status": "formal|proxy|insufficient",
  "object": {"fund_code": "000001", "portfolio_id": "组合标识", "share_class": "A"},
  "period": {"start": "YYYY-MM-DD", "end": "YYYY-MM-DD", "as_of": "YYYY-MM-DD"},
  "parameters": {},
  "sources": [{"id": "s1", "uri": "文件或链接", "data_date": "YYYY-MM-DD", "published_at": null, "retrieved_at": "ISO时间", "hash": null}],
  "coverage": {"holding_nav_weight": null, "stock_weight": null, "mapped_weight": null, "universe_count_ratio": null, "universe_aum_ratio": null},
  "metrics": [{"id": "m1", "name": "指标名", "value": null, "unit": "%", "source_ids": ["s1"], "method": "公式/脚本版本"}],
  "claims": [{"text": "判断", "kind": "fact|inference", "metric_ids": ["m1"], "source_ids": ["s1"], "limitations": []}],
  "missing": [], "warnings": []
}
```
枚举字段选择其中一个值，不写竖线串。无证据的观点不放入 claims。formal 仅表示满足所用方法数据要求，不保证因果解释。

收益输入：date,total_return_index；必须确认收益指数已含分红再投资，不能把累计净值列重命名。CSV 使用 UTF-8，日期 YYYY-MM-DD。
持仓输入：portfolio_id,fund_code,report_date,published_at,security_id,market,currency,weight_nav,shares,market_value,completeness,source_id。weight_nav 为小数；未知 shares/market_value 保持空值；completeness 为 full 或 top10。
因子输入：security_id,as_of,published_at,industry_version,因子列；财务公开日期不能晚于分析时点。

公共计算工具：插件根目录 scripts/fund_metrics.py（函数清单见 methodology.md 第 9 节）。CLI：
```
python scripts/fund_metrics.py tri --input nav.csv --output tri.csv          # date,unit_nav[,distribution][,split_ratio]
python scripts/fund_metrics.py nav --input tri.csv --output metrics.json --confirmed-total-return [--benchmark bench.csv] [--calendar cal.csv | --benchmark-is-calendar] [--periods 252]
```
`bench.csv` 列为 date,total_return_index 或 date,close（价格指数需注明不含分红）。工具不自动采集、不做回归显著性检验或完整基金归因。BF/GRAP 函数是可测试的数学组件，调用者负责合格输入与基金层映射。其他模块按 methodology.md 执行并保留实现与参数。


代理状态的 claims 仍须给出可读判断，并在 limitations 写明“升级为正式所需数据”。
