# fund-research 1.2.4

中国主动权益公募基金研究插件，20 个技能入口，五层架构。本包参考国金证券《大模型赋能投研之二十四：基金研究Skills》（2026-07-23）公开披露的体系蓝图独立实现，非国金证券官方源码或认证产品。

```
任务规划层    fund-research-planner（意图识别 → 路由 → 关键歧义才澄清 → 编排执行）
高阶编排层    equity-fund-product-report / manager-portrait / compare /
              manager-consistency / manager-self-review
专项入口层    active-equity-report-analysis / equity-single-fund-report-analysis /
              theme-search / intraday-nav / similar-search / crowding-analysis
分析子SKILL层  performance / style / industry / asset-allocation / attribution /
              trading-behavior / investability / manager-latest-viewpoints
数据与证据层   references/（数据通道、方法、结果契约、交付模板、执行约束）+ scripts/
```

## 目录

| 路径 | 内容 |
|---|---|
| `references/data-access.md` | 数据优先级、数据检查、时点边界、**akshare 接口速查表**、季报条件下的可执行清单 |
| `references/methodology.md` | 八大模块方法与解释边界、计算工具映射、**默认研究参数表** |
| `references/result-contract.md` | 统一 JSON 结果契约（正式 / 代理 / 数据不足）与 CLI 输入格式 |
| `references/deliverables.md` | 交付规模判定、Excel / Word / HTML 默认版式模板 |
| `references/execution-rules.md` | 所有 SKILL 共用的执行约束 |
| `references/templates/dashboard.html` + `scripts/render_dashboard.py` | 业绩看板模板与填充脚本（无外部依赖） |
| `scripts/fund_metrics.py` | 标准库计算工具：收益指数重建、业绩与相对基准指标、集中度、结构变化、BF/GRAP |

## 安装

以插件方式安装时保留完整目录；单独复制某个 skill 时须同时保留根目录 `references/` 与 `scripts/`（SKILL.md 用 `../../` 相对引用）。各平台安装方式不同，以当前平台支持的插件 / 技能导入功能为准。

验证：`python scripts/test_fund_metrics.py`（29 项测试）。

## 1.2.4 改动

看板数据不再按基准日期删减基金序列：基金保留完整序列，回撤与年度收益始终由基金自身序列计算；基准按基金日期映射，缺失处为空、不插值，并在数据说明中注明缺失天数。累计收益对比以区间内基准首个有效日为共同起点重定基；基准年度收益按年内首末有效值计算并标注缺失天数。修复了基准缺失基金暴跌日时，KPI 最大回撤与回撤图不一致的问题，并新增回归测试。

## 1.2.3 改动

1. **捕获率改为平均期收益之比**：原实现把不连续的上涨/下跌日累计复利，长区间（>2 年）下 down_capture 恒≈1.0、up_capture 失真。
2. **相对计算不再静默丢弃日期**：基金、基准分别在共同区间内检查，原因并入 `withheld_reasons`（带 fund:/bench: 前缀）；确认了但实际残缺的基准日历会被拦截，基金历史长于基准不受影响。
3. 新增 4 项测试：缺陷 A 及其边界（基金历史长于基准不误拦）、长区间捕获率、看板渲染；其中缺陷 A 与捕获率用例在 1.2.2 上失败、1.2.3 通过。
4. `data-access.md` 新增“净值序列清洗”固定工序：剔除非交易日展示净值、处理非日频早期段、复核跳变、分红反推的精度与核对要求、价格指数基准的偏差提示。
5. **可视化**：新增 HTML 看板模板与填充脚本，数值全部来自计算结果，图表在浏览器端由完整序列计算，避免手写绘图脚本出错；Word 图表与看板用同一组图和配色。

## 1.2.2 改动

收紧 `_check_series()` 的日历有效性判断，逐期/年化指标须同时满足：日历非空且覆盖分析区间、序列无日历外日期、区间内无缺失交易日、日历密度与 `periods` 一致（±20%，区间 ≥90 天时检查）。基准日期只有在 `--benchmark-is-calendar`（`benchmark_is_calendar=True`）明确确认完整与频率后才能替代交易日历，日期一致不再默认通过。不满足时返回 `withheld_reasons` 说明原因。

## 1.2.1 改动

1. **收益序列检查统一**：日期、频率、缺失检查集中到 `_check_series()`，绝对与相对计算共用；相对计算在日期对齐后再检查一次。改为按交易日历识别缺失交易日（`--calendar`），取消“7 天 / 15 天”的间隔猜测；有缺失或无日历时只输出累计收益与回撤，不输出年化、跟踪误差、IR、Alpha 等逐期统计。
2. **权重漂移限定为完整组合**：`drift_weights()` 只接受合计 100% 的组合，前十大须显式补“未披露股票”和“现金/债券”项，否则报错；同时校验权重、收益的有效性。`concentration()` 不再静默丢弃 NaN 和负数。

## 1.2 改动

1. **修复**：1.1 在任何 >7 自然日间隔（国庆、春节停市）都会使年化指标为空（1.2.1 已改为交易日历检查）。
2. **恢复 akshare 接口速查表**：按 akshare 1.19.1 核对函数签名，删除已不存在的 `stock_a_indicator_lg`，新增分红 / 拆分、重大变动（实际买卖金额）、持有人结构、申购状态等接口，并标注常见口径误用。
3. **恢复交付模板**：交付规模判定表 + Excel / Word / HTML 默认结构。
4. **扩展计算工具**：`tri` 命令由单位净值+分红+拆分重建收益指数；`--benchmark` 输出超额、相对财富超额、跟踪误差、IR、Beta、Alpha、捕获率；新增回撤区间与修复日、索提诺、Calmar、HHI / 有效数量、无交易权重漂移。
5. **测试补实**：从 6 项增至 13 项，覆盖节假日缺口、拆分、日期对齐、CLI 端到端；“无交易也改变权重”测试改为实际调用函数。
6. **降级而不沉默**：代理状态也要给出带置信度的可读结论和补数清单，避免在前十大数据条件下通篇“无法判断”。
7. **默认研究参数表**：1.1 删除了阈值但未给默认值，1.2 集中给出可配置的默认参数。
8. **去冗余**：20 个文件末尾重复的约束段合并为 `references/execution-rules.md`。
9. **盘中估值**：恢复分步工作流、输出表与组合加权汇总，保留 1.1 的权重漂移、双重计入与情景区间规则。

## 能力边界

未附 Wind 授权或全市场数据；脚本不自动采集数据，也不做回归显著性检验。结果须标明正式 / 代理状态并经人工复核。本套件输出由 AI 基于假设和历史数据生成，仅供参考，不构成投资建议；基金投资有风险，过往业绩不代表未来表现。
