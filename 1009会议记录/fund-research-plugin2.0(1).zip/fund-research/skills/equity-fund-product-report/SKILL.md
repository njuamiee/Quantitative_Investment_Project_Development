---
name: equity-fund-product-report
description: 基金产品评价报告（高阶编排）。一键生成单只基金的完整产品研究/尽调/汇报材料，编排业绩、风格、行业、资产配置、归因、交易行为、可投资性和经理观点全部八个子模块，输出综合分析报告。触发词包括：基金产品评价报告、完整分析这只基金、尽调材料、基金尽调、给我一份XX基金的全面分析、产品研究报告、投委会材料、基金池准入报告。只要用户想要单只基金的全面综合分析（而非单一维度），即触发本 skill。
---

# 基金产品评价报告 SKILL（高阶）

把单项指标分析升级为可直接用于决策的产品研究报告。是基金研究体系最核心的高阶入口。

## 编排流程

1. **前置**：读 `../../references/data-access.md`，**集中预取数据构建缓存**（净值、多期持仓、行业映射、规模、经理信息一次拉齐），避免各子模块重复查库。
2. **按数据依赖执行八个子 SKILL（独立模块可并行）**（读各自 SKILL.md 按其工作流计算，但**不在此阶段生成各自的三件套交付物**，只产出指标结果与单模块小结）：
   equity-fund-performance → equity-fund-style-analysis → equity-fund-industry-analysis → equity-fund-asset-allocation → equity-fund-attribution-analysis → equity-fund-trading-behavior-analysis → equity-fund-investability → equity-fund-manager-latest-viewpoints
3. **汇总校验**：交叉验证关键结论，识别矛盾并显式写入报告（如：明确增配承诺 vs 经验证实际减仓；实际交易成本 vs 收益贡献；风格宣称价值 vs 九宫格落在成长）。
4. **撰写综合报告**（Word，读 `../../references/deliverables.md`）：
   - 一、基金概览与核心结论（1.5 页内给出完整投资画像 + 准入结论）
   - 二、业绩表现 三、投资风格 四、行业配置 五、资产配置与择时 六、业绩归因 七、交易行为 八、可投资性 九、经理观点与言行印证 十、收益来源与风险归纳 + 风险提示
5. **交付**：综合 Word 报告 + 汇总 Excel 底稿（各模块一个 sheet）+ HTML 总看板（综合结论区 + 分模块卡片，便于查结论和细节）。

## 注意

- 适用场景：基金池准入、重点基金尽调、汇报材料撰写。
- 综合结论必须是跨模块推理的产物，不是八段小结的拼接；每个关键判断注明来自哪个模块的什么证据。

## 执行约束

遵循 `../../references/execution-rules.md`（数据检查、方法、结果契约、compute_only、阈值可配置、降级而不沉默）。
