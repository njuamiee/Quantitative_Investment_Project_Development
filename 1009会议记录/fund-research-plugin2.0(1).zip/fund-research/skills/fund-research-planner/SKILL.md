---
name: fund-research-planner
description: 主动权益基金研究任务规划（路由入口）。解析用户关于基金研究的需求（单基金分析、经理研究、对比、搜索、市场扫描等），从基金研究SKILL体系的19个skill中匹配最合适的一个或多个，对明确任务直接执行，对影响结果的关键歧义先澄清后编排执行。触发词包括：帮我研究一下XX基金、基金研究、我想分析基金但不知道从哪开始、基金分析怎么做、以及任何涉及公募基金/主动权益基金但意图不明确、可能需要多个分析维度的请求。当用户的基金类需求模糊或横跨多个维度时，优先触发本 skill 而非直接猜某个子 skill。
---

# 基金研究任务规划 SKILL

先识别对象、目标和输出。明确需求直接路由执行，说明所用默认口径；只对无法可靠推定的代码、区间或关键限制澄清，不重复请求已经给出的授权。

## 第一步：意图识别

解析用户问题，确定三要素：
- **分析对象**：单只基金 / 多只基金 / 基金经理 / 全市场 / 行业·主题
- **分析目标**：想回答什么问题
- **输出偏好**：完整报告 / 快速结论 / 看板 / 底稿

## 第二步：技能路由表

| 用户意图特征 | 推荐 SKILL |
|---|---|
| 单基金·全面了解/尽调/准入 | equity-fund-product-report（高阶） |
| 单基金·仅业绩/风险收益 | equity-fund-performance |
| 单基金·选股风格/漂移/抱团 | equity-fund-style-analysis |
| 单基金·行业分布/切换 | equity-fund-industry-analysis |
| 单基金·仓位/择时 | equity-fund-asset-allocation |
| 单基金·超额收益来源 | equity-fund-attribution-analysis |
| 单基金·换手/交易习惯 | equity-fund-trading-behavior-analysis |
| 单基金·能不能投/限购/清盘风险 | equity-fund-investability |
| 单基金·最新季报变化 | equity-single-fund-report-analysis |
| 单基金·今天涨跌多少 | equity-fund-intraday-nav |
| 单基金·找相似/替代 | equity-fund-similar-search |
| 多基金·横向比较 | equity-fund-compare（高阶） |
| 经理·整体了解 | equity-fund-manager-portrait（高阶） |
| 经理·观点是什么 | equity-fund-manager-latest-viewpoints |
| 经理·说做是否一致 | equity-fund-manager-consistency（高阶） |
| 经理本人·复盘自己产品 | equity-fund-manager-self-review（高阶） |
| 全市场·季报配置变化 | active-equity-report-analysis |
| 主题/行业·找基金 | equity-fund-theme-search |
| 行业/个股·机构拥挤度 | equity-fund-crowding-analysis |

复合需求（如"找出光模块暴露最高的基金并出一份评价报告"）→ 串行编排：equity-fund-theme-search → equity-fund-product-report。

## 第三步：路由与关键歧义处理

以表格输出：分析对象 / 分析目标 / 推荐 SKILL（含推荐理由）/ 覆盖维度 / 输出形式 / 执行顺序（多 skill 时）。明确任务直接执行；关键歧义才询问。先检查数据可用性，缺数据时执行可用模块并列出补充需求。

## 第四步：编排执行

加载对应 SKILL 的 SKILL.md，把原始问题、基金代码等上下文传递过去；依赖模块串行，独立模块按环境能力并行；子模块 compute_only，集中交付。

## 执行约束

遵循 `../../references/execution-rules.md`（数据检查、方法、结果契约、compute_only、阈值可配置、降级而不沉默）。
